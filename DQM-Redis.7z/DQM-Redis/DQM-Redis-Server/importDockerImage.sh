#!/bin/bash

cat redis-services.img | docker image import --message "Import Redis services" - dqm:redis-services 
