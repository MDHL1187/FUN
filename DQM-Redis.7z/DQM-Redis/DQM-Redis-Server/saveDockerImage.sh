#!/bin/bash

for img in $(docker-compose config | awk '{if ($1 == "image:") print $2;}'); do
  images="$images $img"
  echo "Found docker image: $img"
done

echo "Saving docker images as redis-services.img"
docker save -o redis-services.img $images
