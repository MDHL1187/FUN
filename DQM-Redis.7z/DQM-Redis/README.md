# DQM Redis module

This module provides:

 - Redis server setup instructions using docker compose
 - Redis docker images for Redis server (backend) and Redis commander (Management GUI)
 - Common Redis class handler 

# Redis docker setup

**Prerequisite:**

 - Docker installed
 - Docker compose installed

**Optional:**

 - Redis-cli installed
	 - For Windows, please download the package as [here](https://github.com/MicrosoftArchive/redis/releases)
	 - For WSL, please download the redis-server package.
	 <code>apt -y install redis-server</code>
 - Download Docker-compose in WSL
	- Please run following commands:
	<code>curl -L "https://github.com/docker/compose/releases/download/1.29.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose</code>
	
		<code>chmod +x /usr/local/bin/docker-compose</code>

**Provided:**

 - **docker-compose.yml** for defining docker services for Redis and Redis commander
 *Note: please change the static IP address setting.*
 - **redis.conf** for Redis server configuration. 
 - **redisComm.json** for Redis commander configuration.
 - **run-Redis.sh** for building and running services.
 - **saveDockerImage.sh** for exporting Redis services docker image.
 - **importDockerImage.sh** for manually loading Redis services to docker.

## Locally build, extract and import Redis docker image

 1. For building and run Redis docker images, please run following command:
<code>sh **run-Redis.sh**</code>
 2. For extracting Redis docker images, please run following command:
<code>sh **saveDockerImage.sh**</code>
3. For importing Redis docker images, please run following command:
<code>sh **importDockerImage.sh**</code>

*Note: Exported Redis docker image name will be saved as "**redis-services.img**".*

## Run Redis services

Please use following command:
<code>docker-compose up > /dev/null 2>&1 &</code>

## Stop Redis services

Please use following command:
<code>docker-compose stop</code>

## {DOC} Inspect Redis docker image IP address
For Redis cache:
<code>docker inspect --format='{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' redisCache</code>

For Redis Commander:
<code>docker inspect --format='{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' redisCacheCommander</code>

## {DOC} Test Redis server

1. Run redis-cli
 <code>redis-cli -h [IP address, i.e. 172.18.0.2]</code>
2. Authenticate the Redis service after login to CLI console
<code>auth [redis password, i.e. test123]</code>
3. Perform simple ping command
<code>PING</code>
4. Expected reply from Redis
<code>PONG</code>

## {DOC} Viewing Redis commander in local machine
Open browser and using localhost pointed to port 8081, as follow:
<code>http://localhost:8081</code>
Redis server is registered as "**RedisMaster**" using default communication **port 6379**.