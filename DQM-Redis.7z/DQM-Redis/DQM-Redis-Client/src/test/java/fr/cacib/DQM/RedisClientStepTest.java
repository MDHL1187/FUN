package fr.cacib.DQM;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import org.junit.*;
import redis.embedded.RedisServer;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.List;
import java.util.ArrayList;

public class RedisClientStepTest {
	
	private static RedisServer redisServer;
	private static RedisClient redis;
	private static int port;
	
	@Given("^Redis instance$")
	public void initRedisServer()throws Throwable {
		
		//redis = RedisClient.getInstance("127.0.0.1", 6379, "test123"); // for local remote Redis test
		
        port = 6677;
        redisServer = new RedisServer(port);
		if (!redisServer.isActive()) {
            redisServer.start();
        }
		redis = RedisClient.getInstance("127.0.0.1", 6677, "");
	}
	
	@When("^Connect Redis server$")
	public void connectRedisServer() throws Throwable {
		Assert.assertEquals(redis.ping(), true);
		redis.flush();
	}
	
	@Then("^Run full test$")
	public void baseTest() throws Throwable {
		testKeys();
		testListStructure();
		testUnorderSetStructure();
		testHashStructure();
		testOrderSetStructure();
	}
	
	public void testKeys() {
		HashMap<String, String> keyValues = new HashMap<String, String>();
        keyValues.put("testData:value1", "aaa");
        keyValues.put("testData:value2", "bbb");
        keyValues.put("testData:value3", "ccc");
        redis.addKeys(keyValues);
        Set<String> readKeys = redis.getAllKeys("testData*");
        Assert.assertEquals(keyValues.size(), readKeys.size());
	}
	
	public void testListStructure(){
		ArrayList<String> setMembers = new ArrayList<String>();
        setMembers.add("testListValue1");
        setMembers.add("testListValue2");
        setMembers.add("testListValue3");
        redis.prependListValues("testData", setMembers.toArray(new String[0]));
        List<String> readSetMembers = redis.getAllListValuesFromRange("testData", 0, -1);
		Assert.assertEquals(readSetMembers.get(0), "testListValue3");
		Assert.assertEquals(readSetMembers.get(1), "testListValue2");
		Assert.assertEquals(readSetMembers.get(2), "testListValue1");
        Assert.assertEquals(setMembers.size(), readSetMembers.size());
		redis.prependListValues("testData", null);
		redis.flush();
		setMembers = new ArrayList<String>();
        setMembers.add("testListValue1");
        setMembers.add("testListValue2");
        setMembers.add("testListValue3");
        redis.appendListValues("testData", setMembers.toArray(new String[0]));
        readSetMembers = redis.getAllListValuesFromRange("testData", 0, -1);
		Assert.assertEquals(readSetMembers.get(0), "testListValue1");
		Assert.assertEquals(readSetMembers.get(1), "testListValue2");
		Assert.assertEquals(readSetMembers.get(2), "testListValue3");
        Assert.assertEquals(setMembers.size(), readSetMembers.size());
		
		readSetMembers = redis.getAllListValuesFromRange("testData123", 0, -1);
		
		redis.appendListValues("testData", null);
	}
	
	public void testUnorderSetStructure(){
		HashSet<String> setMembers = new HashSet<String>();
        setMembers.add("testUnorderSetValue1");
        setMembers.add("testUnorderSetValue2");
        setMembers.add("testUnorderSetValue3");
        redis.addUnorderedSetValues("testDataSet", setMembers.toArray(new String[setMembers.size()]));
        Set<String> readSetMembers = redis.getAllUnorderedSetValues("testDataSet");
        Assert.assertEquals(setMembers.size(), readSetMembers.size());
		
		readSetMembers = redis.getAllUnorderedSetValues("testData");
        Assert.assertEquals(0, readSetMembers.size());
		
		redis.addUnorderedSetValues("testDataSet", null);
	}
	
	public void testHashStructure(){
		HashMap<String, String> keyValues = new HashMap<String, String>();
        keyValues.put("testData:TestHashData100", "100");
        keyValues.put("testData:TestHashData200", "200");
        keyValues.put("testData:TestHashData300", "300");
        redis.addHashValues("testDataHash", keyValues);
        Map<String, String> readHash = redis.getAllHashValues("testDataHash");
        Assert.assertEquals(keyValues.size(), readHash.size());
		
		readHash = redis.getAllHashValues("testData");
		Assert.assertEquals(0, readHash.size());
		
		redis.addHashValues("testDataHash", null);
	}
	
	public void testOrderSetStructure(){
		HashMap<String, Double> scoreMembers = new HashMap<String, Double>();
        scoreMembers.put("testOrderSetValue1", (double) 33);
        scoreMembers.put("testOrderSetValue2", (double) 44);
        scoreMembers.put("testOrderSetValue3", (double) 55);
        redis.addOrderedSetValues("testDataUnorderedSet", scoreMembers);
        Set<String> readSetMembers = redis.getOrderedSetValuesFromRange("testDataUnorderedSet", 0, -1);
        Assert.assertEquals(readSetMembers.size(), scoreMembers.size());
		
		readSetMembers = redis.getOrderedSetValuesFromRange("testDataUnorderedSet", 0, 0);
        Assert.assertEquals(1, readSetMembers.size());
		
		readSetMembers = redis.getOrderedSetValuesFromRange("testDataUnorderedSet", 0, 1);
        Assert.assertEquals(2, readSetMembers.size());
		
		readSetMembers = redis.getOrderedSetValuesFromRange("testDataUnorderedSet", 0, 2);
        Assert.assertEquals(3, readSetMembers.size());
		
		readSetMembers = redis.getOrderedSetValuesFromRange("testData", 0, -1);
        Assert.assertEquals(0, readSetMembers.size());
		
		redis.addOrderedSetValues("testDataUnorderedSet", null);
	}
	
	@cucumber.api.java.After
	public void closeRedis(){
		redis.flush();
		redis.destroy();
		if (redisServer.isActive()) {
            redisServer.stop();
        }
	}
	
}