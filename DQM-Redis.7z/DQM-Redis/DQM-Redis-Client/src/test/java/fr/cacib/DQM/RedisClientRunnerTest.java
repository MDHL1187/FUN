package fr.cacib.DQM;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="Features", glue={"fr.cacib.DQM"}, plugin={"pretty", "junit:target/cucumber-junit.xml", "html:target/cucumber-reports"})
public class RedisClientRunnerTest {
	
}