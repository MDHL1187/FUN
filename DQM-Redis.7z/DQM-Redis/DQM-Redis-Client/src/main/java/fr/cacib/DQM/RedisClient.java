package fr.cacib.DQM;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.List;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.ArrayList;

public class RedisClient {
    private static Logger logger = LoggerFactory.getLogger(RedisClient.class);

    private static volatile RedisClient instance = null;
	private HashMap<String, String> mapJedisDetails;

    private static JedisPool jedisPool;
	
    public static RedisClient getInstance(String ip, final int port, final String password) {
        if (instance == null) {
            synchronized (RedisClient.class) {
                if (instance == null) {
                    instance = new RedisClient(ip, port, password);
                }
            }
        }
        return instance;
    }

    private RedisClient(String ip, int port, String password) {
        try {
            if (jedisPool == null) {
                jedisPool = new JedisPool(new URI("http://" + ip + ":" + port));
            }
			mapJedisDetails = new HashMap<>();
			mapJedisDetails.put(ip + ":" + port, password);
        } catch (URISyntaxException e) {
            logger.error("Invalid server address", e);
        }
    }
	
	protected Jedis getJedisWithAuth(){
		Jedis jedis = jedisPool.getResource();
		String key = jedis.getClient().getSocket().getInetAddress().getCanonicalHostName()
			+ ":" +  jedis.getClient().getSocket().getPort();
		if(mapJedisDetails.containsKey(key)){
			String pass = mapJedisDetails.get(key);
			if(!pass.isEmpty()){
				jedis.auth(pass);
				logger.info("Logon to Redis " + key);
			}
		}
		return jedis;
	}
	
	public boolean ping(){
		Jedis jedis = getJedisWithAuth();
		return jedis.ping().equalsIgnoreCase("PONG");
	}
	
	/* Start API declaration for Redis List data structure */

    public Long prependListValues(final String key, final String[] strings) {
        try (Jedis jedis = getJedisWithAuth()) {
            return jedis.lpush(key, strings); // size of the key list
        } catch (Exception ex) {
            logger.error("Error while prepend List values on key = " + key, ex);
        }
        return null;
    }
	
	public Long appendListValues(final String key, final String[] strings) {
        try (Jedis jedis = getJedisWithAuth()) {
            return jedis.rpush(key, strings); // size of the key list
        } catch (Exception ex) {
            logger.error("Error while append List values on key = " + key, ex);
        }
        return null;
    }

    public List<String> getAllListValuesFromRange(final String key, final long start, final long stop) {
        try (Jedis jedis = getJedisWithAuth()) {
            return jedis.lrange(key, start, stop);
        } catch (Exception ex) {
            logger.error("Error while getting List values from range " + start + " to " + stop + " with key = " + key, ex);
        }
        return new LinkedList<String>();
    }
	
	/* End API declaration for Redis List data structure */
	
	/* Start API declaration for Redis Hash data structure */

    public String addHashValues(final String key, final Map<String, String> hash) {
        try (Jedis jedis = getJedisWithAuth()) {
            return jedis.hmset(key, hash);
        } catch (Exception ex) {
            logger.error("Error while setting Hash values with key = " + key, ex);
        }
        return null;
    }

    public Map<String, String> getAllHashValues(final String key) {
        try (Jedis jedis = getJedisWithAuth()) {
            return jedis.hgetAll(key);
        } catch (Exception ex) {
            logger.error("Error while getting all Hash values with key = " + key, ex);
        }
        return new HashMap<String, String>();
    }
	
	/* End API declaration for Redis Hash data structure */

	/* Start API declaration for Redis Unordered Set data structure */

    public Long addUnorderedSetValues(final String key, final String... members) {
        try (Jedis jedis = getJedisWithAuth()) {
            return jedis.sadd(key, members);
        } catch (Exception ex) {
            logger.error("Error while adding new unordered Set values, if any, with key = " + key, ex);
        }
        return null;
    }

    public Set<String> getAllUnorderedSetValues(final String key) {
        try (Jedis jedis = getJedisWithAuth()) {
            return jedis.smembers(key);
        } catch (Exception ex) {
            logger.error("Error while getting unordered Set values with key = " + key, ex);
        }
        return new HashSet<String>();
    }
	
	/* End API declaration for Redis Unordered Set data structure */

	/* Start API declaration for Redis Ordered Set data structure */

    public Long addOrderedSetValues(final String key, final Map<String, Double> scoreMembers) {
        try (Jedis jedis = getJedisWithAuth()) {
            return jedis.zadd(key, scoreMembers);
        } catch (Exception ex) {
            logger.error("Error while getting ordered Set values with key = " + key, ex);
        }
        return 0L;
    }

    public Set<String> getOrderedSetValuesFromRange(final String key, final long start, final long stop) {
        try (Jedis jedis = getJedisWithAuth()) {
            return jedis.zrange(key, start, stop);
        } catch (Exception ex) {
            logger.error("Error while getting ordered Set values from range " + start + " to " + stop + " with key = " + key, ex);
        }
        return new HashSet<String>();
    }
	
	/* End API declaration for Redis Ordered Set data structure */

    public String addKeys(final HashMap<String, String> keysValues) {
        try (Jedis jedis = getJedisWithAuth()) {
            ArrayList<String> keysValuesArrayList = new ArrayList<String>();
            keysValues.forEach((key, value) -> {
                keysValuesArrayList.add(key);
                keysValuesArrayList.add(value);
            });
            return jedis.mset((keysValuesArrayList.toArray(new String[keysValues.size()])));
        } catch (Exception ex) {
            logger.error("Error while replacing values", ex);
        }
        return null;
    }

    public Set<String> getAllKeys(final String pattern) {
        try (Jedis jedis = getJedisWithAuth()) {
            return jedis.keys(pattern);
        } catch (Exception ex) {
            logger.error("Error while getting all keys with pattern = " + pattern, ex);
        }
        return new HashSet<String>();
    }

    public void flush() {
        try (Jedis jedis = getJedisWithAuth()) {
            jedis.flushAll();
        } catch (Exception ex) {
            logger.error("Error while flushing Redis cache", ex);
        }
    }
    
    public void destroy() {
        jedisPool = null;
        instance = null;
    }

}