package main.java.com.cacib.interview.sorting.common;

public enum SortingAlgorithm {
    QuickSortRecursive,
    QuickSortStable,
    BubbleSort,
    MergeSortRecursive
}
