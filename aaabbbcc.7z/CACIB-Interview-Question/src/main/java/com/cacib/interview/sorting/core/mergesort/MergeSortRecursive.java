package main.java.com.cacib.interview.sorting.core.mergesort;

import main.java.com.cacib.interview.sorting.common.Sortable;

import java.util.ArrayList;
import java.util.List;

public class MergeSortRecursive<T> extends Sortable<T> {
    @Override
    protected void sort(List<T> array) {
        sort(array, 0, array.size() - 1);
    }

    protected void sort(List<T> array, int low, int high){
        if(low < high){
            int m = low + ((high - low) >> 1);
            sort(array, low, m);
            sort(array, m + 1, high);
            merge(array, low, m, high);
        }
    }

    protected void merge(List<T> array, int low, int mid,  int high){
        int n1 = mid - low + 1;
        int n2 = high - mid;

        var left = new ArrayList<T>(n1);
        var right = new ArrayList<T>(n2);

        for(int i=0; i<n1; i++){
            left.add(array.get(low + i));
        }
        for(int i=0; i<n2; i++){
            right.add(array.get(mid + 1 + i));
        }
        int i=0, j=0, k=low;
        while(i < n1 && j < n2){
            if(comparator.compare(left.get(i), right.get(j)) <= 0){
                array.set(k++, left.get(i++));
            }else{
                array.set(k++, right.get(j++));
            }
        }

        while(i < n1){
            array.set(k++, left.get(i++));
        }

        while(j < n2){
            array.set(k++, right.get(j++));
        }
    }
}
