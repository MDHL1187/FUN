package main.java.com.cacib.interview.tetris.core;

public class FeatureExtraction {
    // simulate if the piece is placed with move i
    // move is 2D array with orientation (index 0) and slot (index 1) information
    // return number of cleared rows
    public static int simulatePlacePiece(State s, int[] top, int[][] field, int piece, int[] move) {
        for (int i = 0; i < State.COLS; i++) {
            top[i] = s.getTop()[i];
        }

        for (int i = 0; i < State.ROWS; i++) {
            for (int j = 0; j < State.COLS; j++) {
                field[i][j] = s.getField()[i][j];
            }
        }

        int orient = 0;
        int slot = 1;

        // fill the slot with piece
        int width = State.getpWidth()[piece][move[orient]];
        int[] bottom = State.getpBottom()[piece][move[orient]];
        int maxTop = 0;

        for (int i = move[slot]; i < move[slot] + width; i++) {
            maxTop = Math.max(maxTop, top[i] - bottom[i - move[slot]]);
        }

        if (maxTop + s.getpHeight()[piece][move[orient]] >= s.ROWS) return 0; // lose

        for (int i = move[slot]; i < move[slot] + width; i++) {
            int colTop = maxTop + State.getpTop()[piece][move[orient]][i - move[slot]];
            int colBottom = maxTop + State.getpBottom()[piece][move[orient]][i - move[slot]];
            for (int j = colBottom; j < colTop; j++) {
                field[j][i] = 1;
            }
            top[i] = colTop;
        }

        int clearRows = 0;
        // clear the full rows
        for (int j = maxTop + State.getpHeight()[piece][move[orient]]; j >= maxTop; j--) {
            int filled = 1;
            for (int i = 0; i < s.COLS; i++) {
                if (field[j][i] == 0) {
                    filled = 0;
                    break;
                }
            }

            if (filled == 1) // clear the row
            {
                clearRows++;
                for (int l = 0; l < s.COLS; l++) {
                    for (int m = j; m < top[l]; m++) {
                        field[m][l] = field[m + 1][l];
                    }
                    top[l]--;
                    while (top[l] >= 1 && field[top[l] - 1][l] == 0) top[l]--;
                }
            }
        }

        return clearRows;
    }

    public static int highestCol(int[] top, int[][] field) {
        int count = 0;

        for (int i = 0; i < State.COLS; i++) {
            if (count < top[i]) count = top[i];
        }

        return count;
    }

    // 2 number of holes
    public static int numberOfHoles(State s, int[] top, int[][] field) {
        int count = 0;

        for (int i = 0; i < s.COLS; i++) {
            for (int j = 0; j < top[i]; j++) {
                if (field[j][i] == 0) count++;
            }
        }

        return count;
    }

    // 3 number of connected holes
    public static int numberOfConnectedHoles(State s, int[] top, int[][] field) {
        int count = 0;

        for (int i = 0; i < s.COLS; i++) {
            for (int j = 0; j < top[i] - 1; j++) {
                if (field[j][i] == 0 && field[j + 1][i] != 0) count++;
            }
        }

        return count;
    }

    // 4 number of rows cleared by last step
    // see function simulatePlacePiece

    // 8 landing height
    public static int landingHeight(State s, int[] top, int[][] field, int[] move) {
        int maxCol = State.getpWidth()[s.getNextPiece()][move[0]];
        int maxHeight = 0;
        for (int i = move[1]; i < move[1] + maxCol; i++) {
            maxHeight = Math.max(top[i], maxHeight);
        }
        return maxHeight;
    }

    // 11 row transitions
    public static int rowTransitions(State s, int[] top, int[][] field) {
        int count = 0;
        int maxTop = 0;
        int previous = 1;

        for (int i = 0; i < s.COLS; i++)
            maxTop = Math.max(maxTop, top[i]);

        for (int i = 0; i < maxTop; i++) {
            previous = 1;
            for (int j = 0; j < s.COLS; j++) {
                if (field[i][j] == 0 && (previous != 0)) {
                    count += 2;
                }
                previous = field[i][j];
            }
        }

        return count;
    }

    // 12 col transitions
    public static int colTransitions(State s, int[] top, int[][] field) {
        int count = 0;
        int previous = 1;

        for (int i = 0; i < s.COLS; i++) {
            previous = 1;
            for (int j = 0; j < top[i]; j++) {
                if (field[j][i] == 0 && (previous != 0)) {
                    count += 2;
                }
                previous = field[j][i];
            }
        }

        for (int i = 0; i < State.COLS; i++) {
            if ((i == 0 && top[i] < top[i + 1]) || (i == State.COLS - 1 && top[i] < top[i - 1])) count++;
            else if ((i > 0 && i < State.COLS - 1) && top[i] < top[i - 1] && top[i] < top[i + 1]) count++;
        }

        return count;
    }

    // 13 highest hole
    public static int highestHole(int[] top, int[][] field) {
        int maxTop = 0;
        int minTop = State.ROWS;

        for (int i = 0; i < State.COLS; i++) {
            maxTop = Math.max(maxTop, top[i]);
            minTop = Math.min(minTop, top[i]);
        }

        return maxTop - minTop;
    }

    // 15 potential rows
    public static int pontentialRows(int[] top, int[][] field) {
        int count = 0;
        int maxTop = 0;
        int minTop = State.ROWS;

        for (int i = 0; i < State.COLS; i++) {
            maxTop = Math.max(maxTop, top[i]);
            minTop = Math.min(minTop, top[i]);
        }

        for (int i = minTop + 1; i < maxTop; i++) {
            int countFilled = 0;
            for (int j = 0; j < State.COLS; j++) {
                if (field[i][j] != 0) countFilled++;
            }
            if (countFilled >= 8) count++;
        }

        return count;
    }
}
