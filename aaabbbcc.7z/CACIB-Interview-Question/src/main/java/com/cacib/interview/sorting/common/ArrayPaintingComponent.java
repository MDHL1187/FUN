package main.java.com.cacib.interview.sorting.common;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Rectangle2D;

public class ArrayPaintingComponent extends JComponent {
    private Double marked1;
    private Double marked2;
    private Double[] values;

    public synchronized void paintComponent(Graphics g){
        if(values == null){
            return;
        }
        Graphics2D g2 = (Graphics2D) g;
        int width = getWidth() / values.length;
        Rectangle2D bar;
        Double v;
        for (int i=0; i < values.length; i++) {
            v = values[i];
            bar = new Rectangle2D.Double(width * i, 0, width, v);
            if(v == marked1){
                g2.setColor(new Color(206, 250, 5));
                g2.fill(bar);
            }else if(v == marked2){
                g2.setColor(new Color(255, 105, 97));
                g2.fill(bar);
            }else{
                g2.setColor(new Color(0, 0, 0));
                g2.draw(bar);
            }
        }
    }

    public synchronized void setValues(Double[] values, Double marked1, Double marked2){
        this.values = values;
        this.marked1 = marked1;
        this.marked2 = marked2;
        repaint();
    }
}
