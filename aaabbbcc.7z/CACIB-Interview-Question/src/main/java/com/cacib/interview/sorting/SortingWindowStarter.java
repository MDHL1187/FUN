package main.java.com.cacib.interview.sorting;

import javax.swing.*;
import java.awt.*;
import lombok.*;
import main.java.com.cacib.interview.core.Criteria;
import main.java.com.cacib.interview.core.Drawable;
import main.java.com.cacib.interview.sorting.common.ArrayPaintingComponent;
import main.java.com.cacib.interview.sorting.common.ArraySorter;
import main.java.com.cacib.interview.sorting.common.SortingCriteria;

@NoArgsConstructor
public class SortingWindowStarter extends Drawable {
    protected Double[] getRandomArray(int size, int panelHeight){
        Double[] values = new Double[size];
        for (int i=0; i<values.length; i++) {
            values[i] = Math.random() * panelHeight;
        }
        return values;
    }

    @Override
    public void startNewWindow(Criteria criteria) {
        if(criteria instanceof SortingCriteria){
            SortingCriteria cr = (SortingCriteria)criteria;

            JFrame frame = new JFrame();
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            ArrayPaintingComponent panel = new ArrayPaintingComponent();
            frame.add(panel, BorderLayout.CENTER);
            frame.setSize(800, 300);
            frame.setVisible(true);

            var sorter = new ArraySorter(getRandomArray(cr.getRandomArraySize(), panel.getHeight()), panel, cr.getSortingAlgorithm());
            Thread t = new Thread(sorter);
            t.start();
        }
    }
}
