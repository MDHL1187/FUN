package main.java.com.cacib.interview.tetris;

import main.java.com.cacib.interview.core.Criteria;
import main.java.com.cacib.interview.core.Drawable;
import main.java.com.cacib.interview.tetris.common.TetrisConfigurationCriteria;
import main.java.com.cacib.interview.tetris.core.PlayerSkeleton;

public class TetrisWindowStarter extends Drawable {
    @Override
    public void startNewWindow(Criteria criteria) {
        if(criteria instanceof TetrisConfigurationCriteria){
            TetrisConfigurationCriteria tc = (TetrisConfigurationCriteria)criteria;
            PlayerSkeleton ps = new PlayerSkeleton(tc);
            ps.start();
        }
    }
}
