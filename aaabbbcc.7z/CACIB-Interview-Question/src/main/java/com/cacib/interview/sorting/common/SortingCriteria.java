package main.java.com.cacib.interview.sorting.common;

import lombok.*;
import main.java.com.cacib.interview.core.Criteria;
import main.java.com.cacib.interview.sorting.common.SortingAlgorithm;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SortingCriteria extends Criteria {
    @Builder.Default
    private SortingAlgorithm sortingAlgorithm = SortingAlgorithm.MergeSortRecursive;
    @Builder.Default
    private int randomArraySize = 30;
}
