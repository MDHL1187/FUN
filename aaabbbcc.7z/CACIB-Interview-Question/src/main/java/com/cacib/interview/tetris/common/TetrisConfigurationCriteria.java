package main.java.com.cacib.interview.tetris.common;

import lombok.*;
import main.java.com.cacib.interview.core.Criteria;
import main.java.com.cacib.interview.tetris.core.State;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TetrisConfigurationCriteria extends Criteria {
    public enum Level {
        Hard,
        Extreme,
        Normal
    };

    public enum PlayStyle{
        Automatic,
        Playable,
        OptimizationMode
    }

    public enum OptimizationAlgorithm{
        Harmomy,
        Genetic
    }

    @Builder.Default
    private Level level = Level.Normal;
    @Builder.Default
    private PlayStyle playStyle = PlayStyle.Automatic;
    @Builder.Default
    private int animationTime = 100;
    @Builder.Default
    private int optimizationMaxIteration = 1000;
    @Builder.Default
    private OptimizationAlgorithm optimizationAlgorithm = OptimizationAlgorithm.Harmomy;
}
