package main.java.com.cacib.interview.sorting.common;

import lombok.NoArgsConstructor;
import main.java.com.cacib.interview.sorting.core.bubblesort.BubbleSort;
import main.java.com.cacib.interview.sorting.core.mergesort.MergeSortRecursive;
import main.java.com.cacib.interview.sorting.core.quicksort.QuickSortRecursive;
import main.java.com.cacib.interview.sorting.core.quicksort.QuickSortStable;

import java.util.Objects;

@NoArgsConstructor
public class SortingFactory {
    private static SortingFactory INSTANCE;

    public static SortingFactory getInstance(){
        if(Objects.isNull(INSTANCE)){
            INSTANCE = new SortingFactory();
        }
        return INSTANCE;
    }

    public <T> Sortable<T> getSortingAlgo(SortingAlgorithm algo){
        switch(algo){
            case QuickSortRecursive:
                return new QuickSortRecursive<T>();
            case QuickSortStable:
                return new QuickSortStable<T>();
            case BubbleSort:
                return new BubbleSort<T>();
            case MergeSortRecursive:
                return new MergeSortRecursive<T>();
        }
        return null;
    }
}
