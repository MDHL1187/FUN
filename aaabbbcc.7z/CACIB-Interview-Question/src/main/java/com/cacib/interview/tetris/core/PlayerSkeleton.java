package main.java.com.cacib.interview.tetris.core;

import lombok.AllArgsConstructor;
import lombok.Getter;
import main.java.com.cacib.interview.tetris.common.TetrisConfigurationCriteria;
import main.java.com.cacib.interview.tetris.optimization.HarmonyOptimization;
import main.java.com.cacib.interview.tetris.optimization.Optimizable;

import java.io.*;
import java.util.Objects;

@Getter
@AllArgsConstructor
public class PlayerSkeleton {

    private TetrisConfigurationCriteria tetrisConfigurationCriteria;

    public int pickMove(State s, int[][] legalMoves, double[] weight) {
        int[] top = new int[State.COLS];
        int[][] field = new int[State.ROWS][State.COLS];
        int bestMove = 0;
        double minCost = 1000000;
        int numberOfLegalMove = State.getNumberOfLegalMoves()[s.getNextPiece()];

        for (int i = 0; i < numberOfLegalMove; i++) {
            int numberOfRowsCleared = FeatureExtraction.simulatePlacePiece(s, top, field, s.getNextPiece(), legalMoves[i]);
            int numberOfHoles = FeatureExtraction.numberOfHoles(s, top, field);
            int numberOfConnectedHoles = FeatureExtraction.numberOfConnectedHoles(s, top, field);
            int landingHeight = FeatureExtraction.landingHeight(s, top, field, legalMoves[i]);
            int rowTransition = FeatureExtraction.rowTransitions(s, top, field);
            int colTransition = FeatureExtraction.colTransitions(s, top, field);
            int highestHole = FeatureExtraction.highestHole(top, field);
            int potentialRows = FeatureExtraction.pontentialRows(top, field);
            int highestCol = FeatureExtraction.highestCol(top, field);
            double tmpCost = weight[0] * numberOfRowsCleared + weight[1] * numberOfHoles + weight[2] * numberOfConnectedHoles + weight[3] * landingHeight + weight[4] * rowTransition + weight[5] * colTransition + weight[6] * highestHole + weight[7] * potentialRows + weight[8] * highestCol;

            if (minCost > tmpCost) {
                minCost = tmpCost;
                bestMove = i;
            }
        }

        return bestMove;
    }

    public void start() {
        switch(tetrisConfigurationCriteria.getPlayStyle()){
            case Automatic:
                startWithAutomatic();
                break;
            case OptimizationMode:
                startWithOptimization();
                break;
            case Playable:
                startWithPlayable();
                break;
        }
    }

    private void startWithAutomatic(){
        double[] trainedWeight = {-27.31414507010502,20.94012828866108,26.619853614716845,16.10642669602445,13.599975898038906,11.457393362817813,-7.715601454853005,20.86620663603526,-27.103911476415266};

        State s = new State(tetrisConfigurationCriteria.getLevel());
        new TFrame(s);
        while (!s.hasLost()) {
            int move = pickMove(s, s.legalMoves(), trainedWeight);
            s.makeMove(move);
            s.draw();
            s.drawNext(0, 0);
            try {
                Thread.sleep(tetrisConfigurationCriteria.getAnimationTime());
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("You have completed " + s.getRowsCleared() + " rows.");
    }

    private void startWithOptimization(){
        Optimizable optimazable = null;
        switch (tetrisConfigurationCriteria.getOptimizationAlgorithm()){
            case Harmomy:
                optimazable = new HarmonyOptimization();
                break;
            case Genetic:
                    break;
        }
        if(Objects.nonNull(optimazable)){
            optimazable.Optimize(tetrisConfigurationCriteria);
        }
    }

    private void startWithPlayable(){
        State s = new State(tetrisConfigurationCriteria.getLevel());
        TFrame t = new TFrame(s);
        s.draw();
        s.drawNext(0, 0);
        t.save("picture.png");
    }
}

