package main.java.com.cacib.interview;

import main.java.com.cacib.interview.tetris.TetrisWindowStarter;
import main.java.com.cacib.interview.tetris.common.TetrisConfigurationCriteria;

public class ApplicationMain {
    public static void main(String[] args) {
        //SortingWindowStarter qw = new SortingWindowStarter();
        //qw.startNewWindow(SortingCriteria.builder().build());

        TetrisWindowStarter tw = new TetrisWindowStarter();
        tw.startNewWindow(TetrisConfigurationCriteria.builder().playStyle(TetrisConfigurationCriteria.PlayStyle.Automatic).animationTime(0).build());

        //SudokuWindowStarter sw = new SudokuWindowStarter();
        //sw.startNewWindow();
    }
}