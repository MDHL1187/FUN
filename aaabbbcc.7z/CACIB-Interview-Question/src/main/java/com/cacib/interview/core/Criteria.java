package main.java.com.cacib.interview.core;

public abstract class Criteria {

}
