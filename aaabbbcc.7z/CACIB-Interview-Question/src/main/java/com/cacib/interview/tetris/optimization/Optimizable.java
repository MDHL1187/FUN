package main.java.com.cacib.interview.tetris.optimization;

import main.java.com.cacib.interview.tetris.common.TetrisConfigurationCriteria;

public abstract class Optimizable {
    public abstract void Optimize(TetrisConfigurationCriteria criteria);
}
