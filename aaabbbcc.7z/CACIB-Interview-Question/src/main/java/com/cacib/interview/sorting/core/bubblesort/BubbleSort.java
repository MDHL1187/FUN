package main.java.com.cacib.interview.sorting.core.bubblesort;

import main.java.com.cacib.interview.sorting.common.Sortable;

import java.util.List;

public class BubbleSort<T> extends Sortable<T> {
    @Override
    protected void sort(List<T> array){
        int size = array.size();
        for(int i=0; i<size; i++){
            for(int j=1; j<size - i; j++){
                if(comparator.compare(array.get(j  -1), array.get(j)) > 0){
                    swap(array, j  -1, j);
                }
            }
        }
    }
}
