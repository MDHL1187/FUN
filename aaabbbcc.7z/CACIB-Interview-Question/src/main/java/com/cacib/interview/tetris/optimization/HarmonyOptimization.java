package main.java.com.cacib.interview.tetris.optimization;

import main.java.com.cacib.interview.tetris.common.TetrisConfigurationCriteria;
import main.java.com.cacib.interview.tetris.core.PlayerSkeleton;
import main.java.com.cacib.interview.tetris.core.State;

import java.io.BufferedWriter;
import java.io.FileWriter;

public class HarmonyOptimization extends Optimizable{
    TetrisConfigurationCriteria tetrisConfigurationCriteria;

    @Override
    public void Optimize(TetrisConfigurationCriteria criteria) {
        if(criteria instanceof TetrisConfigurationCriteria){
            tetrisConfigurationCriteria = (TetrisConfigurationCriteria)criteria;
            doOptimizing();
        }
    }

    private void doOptimizing(){
        int maximumImproveIteration = tetrisConfigurationCriteria.getOptimizationMaxIteration();
        int maximumPiece = 35000;
        int numberOfWeightSets = 5;
        int numberOfParameters = 9;
        double[][] weights = {
                {-22.682537755747475,21.94012828866108,23.065054391004452,16.10642669602445,13.599975898038906,12.457393362817813,-8.715601454853005,20.86620663603526,-27.103911476415266},
                {-5.584686762417348,23.255170054640974,25.619853614716845,16.10642669602445,14.599975898038906,12.457393362817813,-1.6713234621823316,21.136662637191407,-26.103911476415266},
                {-23.682537755747475,20.94012828866108,25.619853614716845,23.874727365088994,15.599975898038906,23.546045835868043,-9.33172511724225,20.86620663603526,-27.103911476415266},
                {-27.31414507010502,20.94012828866108,26.619853614716845,16.10642669602445,13.599975898038906,11.457393362817813,-7.715601454853005,20.86620663603526,-27.103911476415266},
                {-4.584686762417348,21.94012828866108,23.025053664302646,15.10642669602445,14.599975898038906,22.546045835868043,-2.6713234621823316,7.295903531614539,-26.103911476415266}
        };
        int[] clearedRow = new int[numberOfWeightSets];

        for (int i = 0; i < numberOfWeightSets; i++)
            clearedRow[i] = clearedRowFromWeight(weights[i], maximumPiece);

        int max = 0;

        for (int m = 0; m < maximumImproveIteration; m++) {
            System.out.println("Start iteration : " + (m + 1) + ", max. row cleared = " + clearedRow[max] + ", max. piece = " +  maximumPiece);
            double[] newWeight = usingHarmony(weights, numberOfWeightSets);
            int newCleared = clearedRowFromWeight(newWeight, maximumPiece);


            int minCleared = 0;
            for (int i = 1; i < numberOfWeightSets; i++) {
                if (clearedRow[minCleared] > clearedRow[i]) {
                    minCleared = i;
                }
            }

            if (newCleared > clearedRow[minCleared]) {
                weights[minCleared] = newWeight;
                clearedRow[minCleared] = newCleared;
                save(weights, numberOfWeightSets, numberOfParameters, clearedRow, maximumPiece);
            }

            minCleared = 0;
            for (int i = 1; i < numberOfWeightSets; i++) {
                if (clearedRow[minCleared] > clearedRow[i]) {
                    minCleared = i;
                }
            }

            if (clearedRow[minCleared] >= (int) Math.floor(maximumPiece / 2.5) - 10) {
                // Reach near the limit of score for this maximumPiece, 10 is the tolerance
                maximumPiece += 1000;
                for (int u = 0; u < numberOfWeightSets; u++)
                    clearedRow[u] = clearedRowFromWeight(weights[u], maximumPiece);
            }

            max = 0;
            for (int i = 1; i < numberOfWeightSets; i++) {
                if (clearedRow[max] < clearedRow[i]) {
                    max = i;
                }
            }
        }

        for (int i = 0; i < numberOfParameters; i++) {
            System.out.print(weights[max][i]);
            System.out.print(',');
        }
        System.out.println(" ");
        System.out.println("max row cleared " + clearedRow[max]);
        System.out.println("number of pieces " + maximumPiece);
    }

    private double[] usingHarmony(double[][] weight, int numberOfWeight) {
        int maximumNumberIteration = 10;
        double acceptRate = 0.56;
        double pitchAlterRate = 0.45;
        int numberOfParameter = 9;
        double[] newWeight = new double[numberOfParameter];
        double maxValue = 0;
        for (int i = 0; i < numberOfWeight; i++) {
            for (int j = 0; j < numberOfParameter; j++) {
                if (maxValue < Math.abs(weight[i][j])) {
                    maxValue = Math.abs(weight[i][j]);
                }
            }
        }
        for (int i = 0; i < maximumNumberIteration; i++) {
            for (int j = 0; j < numberOfParameter; j++) {
                if (Math.random() < acceptRate) {
                    int index = (int) Math.round(Math.random() * (numberOfWeight - 1));
                    newWeight[j] = weight[index][j];
                    if (Math.random() < pitchAlterRate){
                        if (Math.random() <= 0.5) {
                            newWeight[j] += 1;
                        }
                        else {
                            newWeight[j] -= 1;
                        }
                    }
                } else {
                    if (Math.random() <= 0.5) {
                        newWeight[j] = Math.random() * maxValue;
                    }
                    else {
                        newWeight[j] = -Math.random() * maxValue;
                    }
                }
            }

        }

        return newWeight;
    }

    private int clearedRowFromWeight(double[] weight, int maximumPiece) {
        State s;
        PlayerSkeleton p = new PlayerSkeleton(tetrisConfigurationCriteria);

        //int newCleared = 1000000000;
        //for (int chance = 0; chance < 3; chance++) {
        s = new State(tetrisConfigurationCriteria.getLevel());
        for (int pieceTurn = 0; pieceTurn < maximumPiece && !s.hasLost(); pieceTurn++) {
            int move = p.pickMove(s, s.legalMoves(), weight);
            s.makeMove(move);

        }
        return s.getRowsCleared();
    }

    private void save(double[][] weights, int numberOfWeightSet, int numberOfWeights, int[] clearedRows, int pieces) {
        try {
            FileWriter fstream = new FileWriter("weights.txt");
            BufferedWriter out = new BufferedWriter(fstream);

            for (int i = 0; i < numberOfWeightSet; i++) {
                for (int j = 0; j < numberOfWeights; j++) {
                    out.write("" + weights[i][j]);
                    if(j < numberOfWeights - 1) {
                        out.write(",");
                    }
                }
                out.write("\nclearedRow: " + clearedRows[i] + "\n");
                out.write("pieces: " + pieces + "\n\n");
            }

            out.close();
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }


}
