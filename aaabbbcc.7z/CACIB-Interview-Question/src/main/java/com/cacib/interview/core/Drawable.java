package main.java.com.cacib.interview.core;

import main.java.com.cacib.interview.core.Criteria;

public abstract class Drawable {
    public abstract void startNewWindow(Criteria criteria);
}
