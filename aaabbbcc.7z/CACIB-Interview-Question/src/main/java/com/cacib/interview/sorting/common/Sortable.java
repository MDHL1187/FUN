package main.java.com.cacib.interview.sorting.common;

import java.util.Comparator;
import java.util.List;

public abstract class Sortable<T> {
    protected Comparator<T> comparator;

    public final void sort(List<T> array, Comparator<T> comp){
        this.comparator = comp;
        sort(array);
    }

    protected abstract void sort(List<T> array);

    protected final void swap(List<T> array, int i, int j){
        T temp = array.get(i);
        array.set(i, array.get(j));
        array.set(j, temp);
    }
}
