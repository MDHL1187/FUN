package main.java.com.cacib.interview.soduku;

import main.java.com.cacib.interview.core.Criteria;
import main.java.com.cacib.interview.core.Drawable;
import main.java.com.cacib.interview.soduku.core.Sudoku;

public class SudokuWindowStarter extends Drawable {
    @Override
    public void startNewWindow(Criteria criteria) {
        new Sudoku();
    }
}
