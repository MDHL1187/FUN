package main.java.com.cacib.interview.sorting.core.quicksort;

import main.java.com.cacib.interview.sorting.common.Sortable;

import java.util.List;

public class QuickSortRecursive<T> extends Sortable<T> {
    @Override
    protected void sort(List<T> array){
        //Collections.sort(Array.asList(array), comp);
        quickSort(array, 0, array.size() - 1);
    }

    protected int partition(List<T> array, int low, int high){
        T pivot = array.get(high);
        int i = (low - 1);
        for(int j=low; j<=high; j++){
            if(comparator.compare(array.get(j), pivot) < 0){
                i++;
                swap(array, i, j);
            }
        }
        swap(array, i +1, high);
        return i +1;
    }

    protected void quickSort(List<T> array, int low, int high){
        if(low < high){
            int pv = partition(array, low, high);
            quickSort(array, low, pv - 1);
            quickSort(array, pv + 1, high);
        }
    }
}
