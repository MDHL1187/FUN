package main.java.com.cacib.interview.sorting.common;

import java.util.Arrays;
import java.util.Comparator;

import lombok.*;

@AllArgsConstructor
public class ArraySorter implements Runnable{
    private Double[] values;
    private ArrayPaintingComponent panel;
    private SortingAlgorithm algo;

    @Override
    public void run(){
        var comp = new Comparator<Double>() {
            @Override
            public int compare(Double d1, Double d2) {
                try{
                    Thread.sleep(50);
                }catch(Exception e){
                    System.out.println(e);
                }
                panel.setValues(values, d1, d2);
                return d1.compareTo(d2);
            }
        };
        var sorter = SortingFactory.getInstance().<Double>getSortingAlgo(algo);
        sorter.sort(Arrays.asList(values), comp);
        panel.setValues(values, null, null);
    }
}
