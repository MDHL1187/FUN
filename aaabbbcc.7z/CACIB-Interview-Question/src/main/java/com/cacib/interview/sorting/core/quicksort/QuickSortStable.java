package main.java.com.cacib.interview.sorting.core.quicksort;

import main.java.com.cacib.interview.sorting.common.Sortable;

import java.util.List;

public class QuickSortStable<T> extends Sortable<T> {
    @Override
    protected void sort(List<T> array){
        quickSort(array, 0, array.size() - 1);
    }

    protected int partition(List<T> array, int low, int high){
        T pivot = array.get(high);
        int i = (low - 1);
        for(int j=low; j<=high; j++){
            if(comparator.compare(array.get(j), pivot) < 0){
                i++;
                swap(array, i, j);
            }
        }
        swap(array, i +1, high);
        return i +1;
    }

    protected void quickSort(List<T> array, int low, int high){
        int[] stack = new int[high - low + 1];
        int top = -1;
        stack[++top] = low;
        stack[++top] = high;
        while(top >= 0){
            high = stack[top--];
            low = stack[top--];
            int pv = partition(array, low, high);
            if(pv - 1 > low){
                stack[++top] = low;
                stack[++top] = pv - 1;
            }

            if(pv + 1 < high){
                stack[++top] = pv + 1;
                stack[++top] = high;
            }
        }
    }
}
