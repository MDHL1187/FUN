package fr.efira;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Success extends HttpServlet {

	private static Logger log = LoggerFactory.getLogger(Success.class);
	
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        response.setStatus(HttpServletResponse.SC_OK);
        getClass().getResourceAsStream("/Success.html").transferTo(response.getOutputStream());
		HttpSession session = request.getSession();
		log.info(">>> DEBUG: user id = " + session.getAttribute("SSO-UserId"));
		session.invalidate();
		session = request.getSession();
		log.info(">>> DEBUG: user id after invalidate = " + session.getAttribute("SSO-UserId"));
    }
}
