package fr.efira;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;
import java.io.IOException;

public class Home extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try{
			//response.setContentType("text/html");
			//response.setStatus(HttpServletResponse.SC_OK);
			//getClass().getResourceAsStream("/home.html").transferTo(response.getOutputStream());
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/secure");
			dispatcher.forward(request, response);
		}catch(Exception e){
			throw new RuntimeException(e);
		}
    }
}
