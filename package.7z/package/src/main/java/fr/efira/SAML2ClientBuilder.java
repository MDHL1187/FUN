package fr.efira;

import org.opensaml.saml.common.xml.SAMLConstants;
import org.pac4j.saml.client.SAML2Client;
import org.pac4j.saml.config.SAML2Configuration;
import org.pac4j.core.http.callback.NoParameterCallbackUrlResolver;
import java.lang.management.ManagementFactory;
import javax.management.ObjectName;
import java.io.File;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SAML2ClientBuilder {

	private static Logger log = LoggerFactory.getLogger(SAML2ClientBuilder.class);
	private static String JBOSS_CONFIG_DIR = System.getProperty("jboss.server.config.dir");
	private static String IDP_METADATA_FILE = "idp-metadata.xml";
	private static String KEYSTORE_FILE = "sp-keystore.jks";

    public SAML2Client build() {
        SAML2Configuration config = new SAML2Configuration();
		String idpMetadata = "";
		String filename = JBOSS_CONFIG_DIR + File.separator + IDP_METADATA_FILE;
        //config.setIdentityProviderMetadataResourceUrl(getClass().getResource("/idp-metadata.xml").toString());
        config.setIdentityProviderMetadataResourceFilepath(filename);
        config.setSpLogoutRequestBindingType(SAMLConstants.SAML2_REDIRECT_BINDING_URI);

        // keytool -genkey -keyalg RSA -alias saml -keypass changeit -keystore trust.keystore -storepass changeit
        // config.setKeystorePath("trust.keystore");
        config.setKeystoreResourceFilepath(JBOSS_CONFIG_DIR + File.separator + KEYSTORE_FILE);
        config.setKeystorePassword("test4321");
        config.setPrivateKeyPassword("test4321");
        config.setKeystoreAlias("saml-example");
		
		String port = "8080";
		String host = "localhost";
		try{
			port = ManagementFactory.getPlatformMBeanServer().getAttribute(new ObjectName("jboss.as:socket-binding-group=standard-sockets,socket-binding=http"), "port").toString();
			host = ManagementFactory.getPlatformMBeanServer().getAttribute(new ObjectName("jboss.as:interface=public"), "inet-address").toString();
		}catch(Exception e){
			
		}
		SAML2Client saml2Client = new SAML2Client(config);
        saml2Client.setName("SAMLExample");
        //saml2Client.setCallbackUrl("http://localhost:7777/login");
        saml2Client.setCallbackUrl("http://" + host + ":" + port + "/login");
		saml2Client.setCallbackUrlResolver(new NoParameterCallbackUrlResolver());
        saml2Client.init();

        return saml2Client;
    }
}
